/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oj;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.swing.JOptionPane;
import javax.swing.UIManager;

/**
 *
 * @author manohar
 */
public class NewJFrame extends javax.swing.JFrame {

    /**
     * Creates new form NewJFrame
     */public int id;public boolean value;
     public String prb,language;
     Profilepage backpage;
    
    public NewJFrame(int id,Profilepage backpage) throws SQLException {
        initComponents();
        jComboBox.addItem("c");
        jComboBox.addItem("cpp");
        jComboBox.addItem("java");
        this.id=id;
       this.backpage=backpage;
   jTextArea2.setWrapStyleWord(true);
    jTextArea2.setLineWrap(true);
    jTextArea2.setOpaque(false);
    jTextArea2.setEditable(false);
    jTextArea2.setFocusable(false);
    jTextArea2.setBackground(UIManager.getColor("Label.background"));
    jTextArea2.setFont(UIManager.getFont("Label.font"));
    jTextArea2.setBorder(UIManager.getBorder("Label.border"));

        System.out.println("passed argument"+id);
        jdbc();
    }
    
    public void jdbc() throws SQLException
    {id++;
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/oj", "root", "cccc");
        System.out.println("connection success  1");
                PreparedStatement stmt = conn.prepareStatement("select * from problems where id=?");
                stmt.setInt(1,id);
                ResultSet  st=stmt.executeQuery();
               while( st.next()){
               
                prb=st.getInt(1)+st.getString(3)+"\n";
           
    }     jTextArea2.setText(prb);
    
        
    }
    
     public int execute(String l,String n,long timeInMillis)
    {
       
        System.out.println("Code started executing.");
        ProcessBuilder p;
        if (l.equals("java")) {
            p = new ProcessBuilder("java", "Main");
        } else if (l.equals("c")) {
            p = new ProcessBuilder("./Main");
        } else {
            p = new ProcessBuilder("./Main");
        }
        //p.directory(new File(System.getProperty("dir")));
        File in = new File(n);
        p.redirectInput(in);
        if(in.exists())
            System.out.println("Input file " + in.getAbsolutePath());
        p.redirectErrorStream(true);
        System.out.println("Current directory " + System.getProperty("dir"));
        File out = new File( "/home/manohar/Desktop/output.txt");

        p.redirectOutput(out);
        if(out.exists())
            System.out.println("Output file generated " + out.getAbsolutePath());
        try {

            Process pp = p.start();
            if (!pp.waitFor(timeInMillis, TimeUnit.MILLISECONDS)) {
                return 1;//1 for tle
            }
            int exitCode = pp.exitValue();
            System.out.println("Exit Value = " + pp.exitValue());
            if(exitCode != 0)
                return 2;//run time error
        } catch (IOException ioe) {
            System.err.println("in execute() "+ioe);
        } catch (InterruptedException ex) {
            System.err.println(ex);
        }
        System.out.println("Code execution finished!");
        //delete executables
      //  if(matchfiles())
        //return 3;//accepted
  //else
    //        return 4;//wrong ans
      //  deleteExecutables(l);
        return 3;//accepted
    }
    
    public boolean compile (String l )
    {
        
        System.out.println("Code compilation started...");
        ProcessBuilder p;
        boolean compiled = true;
        if (l.equals("java")) {
           p = new ProcessBuilder("javac", "/home/manohar/Desktop/pro2.java");
        } else if (l.equals("c")) {
            p = new ProcessBuilder("gcc","-std=c++0x","-w","-o", "Main", "/home/manohar/Desktop/pro2.c");
        } else {
           p = new ProcessBuilder("g++","-std=c++0x","-w", "-o", "Main", "/home/manohar/Desktop/pro2.cpp");
        }
//        p.directory(new File(System.getProperty("/home/manohar")));
        p.redirectErrorStream(true);

        try {
            Process pp = p.start();
            InputStream is = pp.getInputStream();
            String temp;
            try (BufferedReader b = new BufferedReader(new InputStreamReader(is))) {
                while ((temp = b.readLine()) != null) {
                    compiled = false;
                    System.out.println(temp);
                }
                pp.waitFor();
            }

            if (!compiled) {
                is.close();
                return false;
            }
            is.close();
            return true;

        } catch (IOException | InterruptedException e) {
            System.out.println("in compile() " + e);
        }

        return false;
    
    }
    
    public void  converttofile(String l) throws IOException
    {   BufferedWriter buf;
    if(l=="c")
    { buf=new BufferedWriter(new FileWriter("/home/manohar/Desktop/pro2.c",false));
      buf.write(UsercodeTextarea.getText());
        buf.newLine();
        buf.close();
    }
    else if(l=="cpp")
    {
        buf=new BufferedWriter(new FileWriter("/home/manohar/Desktop/pro2.cpp",false));
        buf.write(UsercodeTextarea.getText());
        buf.newLine();
        buf.close();}
    else if(l=="java")
    {buf=new BufferedWriter(new FileWriter("/home/manohar/Desktop/pro2.java",false));
    buf.write(UsercodeTextarea.getText());
        buf.newLine();
        buf.close();}
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton5 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTextArea2 = new javax.swing.JTextArea();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        UsercodeTextarea = new javax.swing.JTextArea();
        compileB = new javax.swing.JButton();
        SubmitB = new javax.swing.JButton();
        jComboBox = new javax.swing.JComboBox<>();

        jButton5.setText("jButton5");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButton4.setText("Back");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jTextArea2.setColumns(20);
        jTextArea2.setRows(5);
        jScrollPane3.setViewportView(jTextArea2);

        jLabel3.setText("Enter your code here :");

        UsercodeTextarea.setColumns(20);
        UsercodeTextarea.setRows(5);
        jScrollPane4.setViewportView(UsercodeTextarea);

        compileB.setText("Compile");
        compileB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                compileBActionPerformed(evt);
            }
        });

        SubmitB.setText("Submit");
        SubmitB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SubmitBActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 680, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(307, 307, 307)
                                .addComponent(jLabel3))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(23, 23, 23)
                                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 642, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(112, 112, 112))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButton4)
                        .addGap(181, 181, 181)))
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(68, 68, 68)
                .addComponent(jComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(75, 75, 75)
                .addComponent(compileB)
                .addGap(64, 64, 64)
                .addComponent(SubmitB)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 151, Short.MAX_VALUE))
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 485, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(compileB)
                            .addComponent(SubmitB))
                        .addContainerGap())
                    .addComponent(jComboBox, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);
        backpage.setVisible(true);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void compileBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_compileBActionPerformed
     //   int selected=jComboBox.sele
     language=jComboBox.getSelectedItem().toString();
         try {
             converttofile(language);
         } catch (IOException ex) {
             Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
         }
        value=compile(language);
        if(value)
        {
                JOptionPane.showMessageDialog(this, "Compilation success");
        }else
        {
        JOptionPane.showMessageDialog(this, "Compilation Error!!");}
    }//GEN-LAST:event_compileBActionPerformed

    private void SubmitBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SubmitBActionPerformed
        // TODO add your handling code here:
         language=jComboBox.getSelectedItem().toString();
     int verdict=   execute(language,"/home/manohar/Desktop/in.txt",20);
     if(verdict==1)
     {JOptionPane.showMessageDialog(this, "tle");
     }else if(verdict==2)
     {JOptionPane.showMessageDialog(this, "segfault");
     }
     else if(verdict==3)
     {JOptionPane.showMessageDialog(this, "accepted!!");
     }
     else if(verdict==4)
         JOptionPane.showMessageDialog(this, "wrong answer!!");
         
    }//GEN-LAST:event_SubmitBActionPerformed

    /**
     * @param args the command line arguments
     */
  


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton SubmitB;
    private javax.swing.JTextArea UsercodeTextarea;
    private javax.swing.JButton compileB;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JComboBox<String> jComboBox;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTextArea jTextArea2;
    // End of variables declaration//GEN-END:variables
}
