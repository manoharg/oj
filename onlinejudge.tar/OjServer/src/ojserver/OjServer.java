
package ojserver;

/**
 *
 * @author manohar
 */
public class OjServer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        
    }
    
}
